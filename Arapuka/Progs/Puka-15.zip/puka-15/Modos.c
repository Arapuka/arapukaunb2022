// Puka - Modos.c

#include <msp430.h>
#include "Modos.h"
#include "Gpio.h"
#include "Timer.h"
#include "Serial.h"
#include "Lcd.h"
#include "Mpu.h"
#include "Rtc.h"
#include "Wq.h"
#include "Gps.h"
#include "Strings.h"

//10 - SW - Testar as chaves
char modo_sw  (char modo) {
    char sw1_ct, sw2_ct;    //Contar acionamentos das chaves
    sw1=sw2=FALSE;          //Cancelar acionamentos anteriores
    modo_ser1(modo);
    ser1_str(" Testar SW\n");
    lcdb_str(1,1,"SW");
    lcdb_str(2,1,"SW1=A  SW2=A");
    sw1_ct=sw2_ct=0;
    seri_config();    //Apagar fila de entrada
    ser1_str("SW1=");        ser1_dec8u(sw1_ct);
    ser1_str("  SW2=");      ser1_dec8u(sw2_ct);
    ser1_crlf(1);


    while(TRUE){
        if (seri_cmdo_x()==TRUE)    return modo;

        if (sw1_estado==ABERTA)  lcdb_char(2,5,'A');
        else                     lcdb_char(2,5,'F');
        if (sw2_estado==ABERTA)  lcdb_char(2,12,'A');
        else                     lcdb_char(2,12,'F');

        // SW1
        if (sw1==TRUE){
            sw1=FALSE;
            sw1_ct++;
            ser1_str("SW1=");
            ser1_dec8u(sw1_ct);
            ser1_crlf(1);
        }

        //SW2
        if (sw2==TRUE){
            sw2=FALSE;
            sw2_ct++;
            ser1_str("SW2=");
            ser1_dec8u(sw2_ct);
            ser1_crlf(1);
        }
    }
    return modo;
}

//11 - LEDs
// Testar Leds
// Digitar: VM, vn, Vm, VD, vd, Vd
char modo_leds  (char modo) {
    char qtd,argc[4],argv[10];
    modo_ser1(modo);
    ser1_str(" Testar LEDs\n");
    lcdb_str(1,1,"Leds");
    led_vm();
    led_vd();
    while(TRUE){
        qtd=seri_cmdo(argc,argv,10);
        if(qtd>0){
            if (argv[0]=='X' || argv[0]=='x'){
                led_vm();
                led_vd();
                return modo;
            }
            if      (str_cmp(&argv[0], "VM")) led_VM();
            else if (str_cmp(&argv[0], "vm")) led_vm();
            else if (str_cmp(&argv[0], "Vm")) led_Vm();
            else if (str_cmp(&argv[0], "VD")) led_VD();
            else if (str_cmp(&argv[0], "vd")) led_vd();
            else if (str_cmp(&argv[0], "Vd")) led_Vd();
            else                             ser1_char('?');
        }
    }
    return modo;
}


//12 - LCD
char modo_lcd  (char modo){
    char letra=0,base=0;
    char lin,col;
    modo_ser1(modo);
    while(TRUE){
        if (seri_cmdo_x()==TRUE)    return modo;
        for (lin=1; lin<3; lin++){
            for(col=1; col<17; col ++){
                letra=base+(lin-1)*16+(col-1);
                lcdb_char(lin,col,letra);
            }
        }
        delay_10ms(50);
        base++;
    }
    return modo;
}

//13 - LCD
char modo_mpu  (char modo) {
    char x;
    char vetor[14];
    int ax,ay,az,tp,gx,gy,gz;
    modo_ser1(modo);
    ser1_str(" MPU =");
    lcdb_str(1,1,"MPU");

    x=i2c_teste_adr(MPU_ADR);
    if (x==TRUE)    ser1_str(" OK");
    else{
        ser1_str(" NOK");
        return modo;
    }
    ser1_crlf(1);
    while(TRUE){
        if (seri_cmdo_x()==TRUE)    return modo;
        mpu_rd_vet(ACCEL_XOUT_H, vetor, 14);    //Ler 14 regs
        ax=vetor[ 0];    ax=(ax<<8)+vetor[ 1];
        ay=vetor[ 2];    ay=(ay<<8)+vetor[ 3];
        az=vetor[ 4];    az=(az<<8)+vetor[ 5];
        tp=vetor[ 6];    tp=(tp<<8)+vetor[ 7];
        gx=vetor[ 8];    gx=(gx<<8)+vetor[ 9];
        gy=vetor[10];    gy=(gy<<8)+vetor[11];
        gz=vetor[12];    gz=(gz<<8)+vetor[13];
        ser1_dec16(ax); ser1_spc(1);
        ser1_dec16(ay); ser1_spc(1);
        ser1_dec16(az); ser1_spc(3);
        ser1_dec16(gx); ser1_spc(1);
        ser1_dec16(gy); ser1_spc(1);
        ser1_dec16(gz); ser1_spc(1);
        ser1_crlf(1);
        lcdb_hex16(1,1, ax);
        lcdb_hex16(1,6, ay);
        lcdb_hex16(1,11,az);
        lcdb_hex16(2,1, gx);
        lcdb_hex16(2,6, gy);
        lcdb_hex16(2,11,gz);
        delay_10ms(100);
    }
    return modo;
}

//14 - RTC - Testar o RTC
char modo_rtc  (char modo) {
    char qtd,argc[4], argv[15]; //Receber comandos
    char vetor[7];
    modo_ser1(modo);
    ser1_str(" Testar RTC\n");
    lcdb_str(1,1,"RTC");
    while(TRUE){
        qtd=seri_cmdo(argc,argv,15);  //Esperar comando
        if (qtd!=0){
            ser1_str("Chegou: ");
            ser1_str(&argv[0]);
            ser1_crlf(1);

            if (argv[0]=='x' || argv[0]=='X')   return modo;

            // Hora (hh:mm:ss)
            if (argv[2] == ':' && argv[5]==':'){
              vetor[2]=16*(argv[0]-0x30)+(argv[1]-0x30);  //Segundos
              vetor[1]=16*(argv[3]-0x30)+(argv[4]-0x30);  //Minutos
              vetor[0]=16*(argv[6]-0x30)+(argv[7]-0x30);  //Horas
              rtc_wr_vet(0,vetor,3);
            }

            //Data (dd/mm/aa)
            if (argv[2] == '/' && argv[5]=='/'){
              vetor[0]=16*(argv[0]-0x30)+(argv[1]-0x30);  //Dia
              vetor[1]=16*(argv[3]-0x30)+(argv[4]-0x30);  //M�s
              vetor[2]=16*(argv[6]-0x30)+(argv[7]-0x30);  //Ano
              rtc_wr_vet(4,vetor,3);
            }

        }

        rtc_rd_vet(0, vetor, 7);
        ser1_data_hora(vetor);
        ser1_crlf(1);
        lcdb_data(1,9,vetor);
        lcdb_hora(2,9,vetor);
        //ser1_hex8(x);
        //ser1_crlf(1);
        delay_10ms(100);
    }
    return modo;
}

//15 -WQ- Testar memo Flash
char modo_wq (char modo) {
    char qtd,argc[4], argv[15]; //Receber comandos
    char x,i,j;
    char vt[16];
    long wr_adr=0;  //Endere�o para as escritas
    long rd_adr=0;  //Endere�o para as leituras
    long er_adr=0;  //Endere�o para apagar
    modo_ser1(modo);
    ser1_str(" Testar Flash\n");
    lcdb_str(1,1,"WQ");
    x=wq_sr1_rd();
    ser1_str("SR1 = ");
    ser1_hex8(x);

    x=wq_sr2_rd();
    ser1_str("  SR2 = ");
    ser1_hex8(x);
    ser1_crlf(1);

    w25_manuf_dev_id(vt);
    ser1_str("Manuf ID = ");
    ser1_hex8(vt[0]);
    ser1_spc(1);
    ser1_hex8(vt[1]);
    ser1_crlf(1);

    while(TRUE){
        qtd=0;
        while (qtd==0)  qtd=seri_cmdo(argc,argv,15);  //Esperar comando
        if (argv[0]=='x' || argv[0]=='X') return modo;

        //Leitura 256 bytes da Flash
        if (argv[0]=='r' || argv[0]=='R'){
            if (qtd>1){
                rd_adr=str_2_num(&argv[argc[1]]);
                rd_adr &= 0xFFFFFF0;        //Endere�o m�ltiplo de 16
            }
            ser1_str("RD ");
            ser1_hex32(rd_adr);
            ser1_crlf(1);

            for (i=0; i<16; i++){
                wq_rd_blk(rd_adr, vt,16);
                ser1_hex32(rd_adr);
                ser1_char(':');
                ser1_spc(1);
                ser1_linha(vt);
                rd_adr+=16;
            }
            ser1_crlf(1);
        }

        // WR - Escrita de um padr�o de 256 bytes, opera em blocos de 16 bytes
        if (argv[0]=='w' || argv[0]=='W'){
            if (qtd>1){
                wr_adr=str_2_num(&argv[argc[1]]);
                wr_adr &= 0xFFFFFF0;        //Endere�o m�ltiplo de 16
            }
            ser1_str("WR ");
            ser1_hex32(wr_adr);
            ser1_crlf(1);
            x=0;
            for (i=0; i<16; i++){
                for (j=0; j<16; j++)
                    vt[j]=j+x;

                wq_wr_blk(wr_adr, vt,16);
                wr_adr+=16;
                x+=16;
            }
            ser1_str("OK");
            ser1_crlf(1);
        }

        // Erase - Apagar p�gina de 4 KB (adr = aaaa aaaa   aaaa 0000   0000 0000)
        if (argv[0]=='e' || argv[0]=='E'){
            if (qtd>1){
                er_adr=str_2_num(&argv[argc[1]]);
                wr_adr &= 0xFFF000;        //Endere�o m�ltiplo de 4 KB
            }
            ser1_str("Erase 4K: ");
            ser1_hex32(er_adr);
            wq_erase_4k(er_adr);
            ser1_str(" OK");
            ser1_crlf(1);
        }
    }
    return modo;
}

//16 -GPS- Testar GPS
// Usa TA0
char modo_gps  (char modo) {
    char x;
    gps_config();
    modo_ser1(modo);
    ser1_str(" Testar GPS\n");
    lcdb_str(1,1,"GPS");
    while(TRUE){
        if (seri_cmdo_x()==TRUE){
            TA0CTL=0;   //Parar o timer, desligar a serial do GPS
            return modo;
        }
        if (gps_tira(&x)==TRUE)
                ser1_char(x);
    }
    return modo;
}
//17 gps com dados filtrados
char modo_gps_d(char modo){
    char x, y;
    char tipo, i = 0;
    char chegou = FALSE;
    int j = 0;
    char vetor[77];


    gps_config();
    modo_ser1(modo);
    ser1_str(" Filtrar GPS\n");
    lcdb_str(1,1,"GPS Filtro");
    while(TRUE){
        if (seri_cmdo_x()==TRUE){
            TA0CTL=0;   //Parar o timer, desligar a serial do GPS
            return modo;
        }

        if(gps_tira(&y) == TRUE){
            if(y == '$'){
                chegou = TRUE;
            }
            if(chegou == TRUE){
               vetor[i++] = y;
            }
            if(i == 76){
                if(vetor[0] == '$' && vetor[1] == 'G' && vetor[2] == 'P' && vetor[3] == 'G' && vetor[4] == 'G' && vetor[5] == 'A'){
                ser1_str(vetor);
                ser1_crlf(1);
                }
                i = 0;
                chegou = FALSE;
            }
        }
    }
    return modo;

}

//modo 18 configurar rel�gio rtc

char modo_configrtc(char modo){
    char aargc[10], aargv[20];
    char vetor[3];
    char i, aqtd;
    modo_ser1(modo);
    ser1_str(" Configurar RTC\n");
    ser1_str("Digite as horas com ':' ou a data com '/'.\n");
    lcdb_str(1,1,"Config");
    lcdb_str(2,1,"RTC");
        while((aqtd = seri_cmdo(aargc,aargv,20)) == 0){
            if (seri_cmdo_x()==TRUE)    return modo;
        }
         for(i=0; i<aqtd; i++){
          rtc_str(&aargv[aargc[i]]);
         }
         if (seri_cmdo_x()==TRUE)    return modo;
         //ver se � hora
        if (vetor_rtc[2] == ':' && vetor_rtc[5]==':'){
             vetor[2]=16*(vetor_rtc[0]-0x30)+(vetor_rtc[1]-0x30);  //Horas
             vetor[1]=16*(vetor_rtc[3]-0x30)+(vetor_rtc[4]-0x30);  //Minutos
             vetor[0]=16*(vetor_rtc[6]-0x30)+(vetor_rtc[7]-0x30);  //Segundos
             rtc_wr_vet(0,vetor,3);
             ser1_str("Horas atualizada\n");
          }
        //ver se � dia
        else if (vetor_rtc[2] == '/' && vetor_rtc[5]=='/'){
            vetor[0]=16*(vetor_rtc[0]-0x30)+(vetor_rtc[1]-0x30);  //Dia
            vetor[1]=16*(vetor_rtc[3]-0x30)+(vetor_rtc[4]-0x30);  //M�s
            vetor[2]=16*(vetor_rtc[6]-0x30)+(vetor_rtc[7]-0x30);  //Ano
            rtc_wr_vet(4,vetor,3);
            ser1_str("Data Atualizada\n");
         }
        rtc_rd_vet(0, vetor, 7);
        ser1_data_hora(vetor);
        ser1_crlf(1);
        lcdb_data(1,9,vetor);
        lcdb_hora(2,9,vetor);
        return modo;
}

//19 Teste come virgula GPS
char modo_gps_c(char modo){
    float latitude,longitude,m1 = 0,m2 = 0;
    int d1 = 0,d2 = 0;
    char x, y;
    char tipo, i = 0;
    char chegou = FALSE;
    int j = 0;
    char vetor[77];
    char filtro[43];


    gps_config();
    modo_ser1(modo);
    ser1_str(" Filtrar GPS\n");
    lcdb_str(1,1,"GPS Covertido");
    while(TRUE){
        d1 = 0;
        d2 = 0;
        m1 = 0;
        m2 = 0;
        if (seri_cmdo_x()==TRUE){
            TA0CTL=0;   //Parar o timer, desligar a serial do GPS
            return modo;
        }

        if(gps_tira(&y) == TRUE){
            if(y == '$'){
                chegou = TRUE;
            }
            if(chegou == TRUE){
               vetor[i++] = y;
            }
            if(i == 76){
                if(vetor[0] == '$' && vetor[1] == 'G' && vetor[2] == 'P' && vetor[3] == 'G' && vetor[4] == 'G' && vetor[5] == 'A'){
                    while(j < 43){
                        filtro[j] = vetor[j];
                        j++;
                    }
                j = 0;
                d1 = d1 + ((filtro[17] - 48) * 10);
                d1 = d1 + (filtro[18] - 48);
                d2 = d2 + ((filtro[30] - 48) * 100);
                d2 = d2 + ((filtro[31] - 48) * 10);
                d2 = d2 + (filtro[32] - 48);
                m1 = m1 + ((filtro[19] - 48) * 10);
                m1 = m1 + (filtro[20] - 48);
                m1 = m1 + ((filtro[22] - 48) / 10.);
                m1 = m1 + ((filtro[23] - 48) / 100.);
                m1 = m1 + ((filtro[24] - 48) / 1000.);
                m1 = m1 + ((filtro[25] - 48) / 10000.);
                m1 = m1 + ((filtro[26] - 48) / 100000.);
                m2 = m2 + ((filtro[33] - 48) * 10);
                m2 = m2 + (filtro[34] - 48);
                m2 = m2 + ((filtro[36] - 48) / 10.);
                m2 = m2 + ((filtro[37] - 48) / 100.);
                m2 = m2 + ((filtro[38] - 48) / 1000.);
                m2 = m2 + ((filtro[39] - 48) / 10000.);
                m2 = m2 + ((filtro[40] - 48) / 100000.);
                latitude  = d1 + m1/60;
                longitude  = d2 + m2/60;
                if (filtro[28] == 'S') latitude = latitude * (-1);
                if (filtro[42] == 'W') longitude = longitude * (-1);
                ser1_str(filtro);
                ser1_crlf(1);
                ser1_float(latitude, 6);
                ser1_crlf(1);
                ser1_float(longitude, 6);
                ser1_crlf(1);
                }
                i = 0;
                chegou = FALSE;
            }
        }
    }
    return modo;
}
// modo 20 - Gps filtro gprmc
char modo_gprmc(char modo){
        char y,trash;
        int estado = 0;
        int hora = 0, lat = 0, lon = 0, data = 0;


        gps_config();
        modo_ser1(modo);
        ser1_str(" Filtrar GPRMC\n");
        lcdb_str(1,1,"GPS Filtro");
        while(TRUE){
            if (seri_cmdo_x()==TRUE){
                TA0CTL=0;   //Parar o timer, desligar a serial do GPS
                return modo;
            }
            if(gps_tira(&y) == TRUE){
            switch(estado){
            case 0: if(y == '$') estado = 1;
            else estado = 0;
            trash = y;
            break;

            case 1: if(y == 'G') estado = 2;
            else estado = 0;
            trash = y;
            break;

            case 2: if(y == 'P') estado = 3;
            else estado = 0;
            trash = y;
            break;

            case 3: if(y == 'R') estado = 4;
            else estado = 0;
            trash = y;
            break;

            case 4: if(y == 'M') estado = 5;
            else estado = 0;
            trash = y;
            break;

            case 5: if(y == 'C') estado = 6;
            else estado = 0;
            trash = y;
            break;

            case 6: if(y == ',') estado = 7;
            else estado = 0;
            trash = y;
            break;

            case 7: if(y == ','){
                estado = 8;
                hora = 0;
                trash = y;
            }
            else{
                gps_hora[hora++]= y;
            }
            break;

            case 8: if(y == ',') estado = 9;
            else if(y == 'A'){
                gps_stat[0]= y;
            }
            else{
                estado = 0;
                trash = y;
            }
            break;

            case 9: if(y == ','){
                estado = 10;
                lat = 0;
                trash = y;
            }
            else{
                gps_lat[lat++]= y;
            }
            break;

            case 10: if(y == ','){
                estado = 11;
                trash = y;
            }
            else{
                gps_ns[0]= y;
            }
            break;

            case 11: if(y == ','){
                estado = 12;
                lon = 0;
                trash = y;
            }
            else{
                gps_long[lon++]= y;
            }
            break;

            case 12: if(y == ','){
                estado = 13;
                trash = y;
            }
            else{
                gps_ew[0]= y;
            }
            break;

            case 13: if(y == ',') estado = 14;
            trash = y;
            break;

            case 14: if(y == ',') estado = 15;
            trash = y;
            break;

            case 15: if(y == ','){
                estado = 0;
                data = 0;
                trash = y;
            }
            else{
                gps_data[data++]= y;
            }
            break;
            }

                    ser1_str(gps_hora);
                    ser1_crlf(1);
                    ser1_str(gps_stat);
                    ser1_crlf(1);
                    ser1_str(gps_lat);
                    ser1_crlf(1);
                    ser1_str(gps_ns);
                    ser1_crlf(1);
                    ser1_str(gps_long);
                    ser1_crlf(1);
                    ser1_str(gps_ew);
                    ser1_crlf(1);
                    ser1_str(gps_data);
                    ser1_crlf(1);
        }
        }
        return modo;
}

char modo_0   (char modo) { modo_ser1(modo); return modo;}
char modo_1   (char modo) { modo_ser1(modo); return modo;}
char modo_2   (char modo) { modo_ser1(modo); return modo;}
char modo_3   (char modo) { modo_ser1(modo); return modo;}
char modo_4   (char modo) { modo_ser1(modo); return modo;}
char modo_5   (char modo) { modo_ser1(modo); return modo;}
char modo_6   (char modo) { modo_ser1(modo); return modo;}
char modo_7   (char modo) { modo_ser1(modo); return modo;}
char modo_8   (char modo) { modo_ser1(modo); return modo;}
char modo_9   (char modo) { modo_ser1(modo); return modo;}
char modo_16  (char modo) { modo_ser1(modo); return modo;}
char modo_17  (char modo) { modo_ser1(modo); return modo;}
char modo_18  (char modo) { modo_ser1(modo); return modo;}
char modo_19  (char modo) { modo_ser1(modo); return modo;}
char modo_20  (char modo) { modo_ser1(modo); return modo;}
char modo_99  (char modo) { ser1_str("Invalido");  return modo;}

// Imprimir modo no Serial
void modo_ser1(char modo){
    ser1_str("\r\nModo ");   ser1_dec8unz(modo);
}

