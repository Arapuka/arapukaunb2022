// Puka - Modos.c

#include <msp430.h>
#include "Modos.h"
#include "Gpio.h"
#include "Serial.h"
#include "Strings.h"

//10 - SW - Testar as chaves
char modo_sw  (char modo) {
    char sw1_ct, sw2_ct;    //Contar acionamentos das chaves
    modo_ser1(modo);
    ser1_str(" Testar SW\n");

    sw1_ct=sw2_ct=0;
    seri_config();    //Apagar fila de entrada
    ser1_str("\r\nModo 11: Chaves\r\n");
    ser1_str("SW1=");        ser1_dec8u(sw1_ct);
    ser1_str("  SW2=");      ser1_dec8u(sw2_ct);
    ser1_crlf(1);


    while(TRUE){
        if (seri_cmdo_x()==TRUE)    return modo;

        // SW1
        if (sw1==TRUE){
            sw1=FALSE;
            sw1_ct++;
            ser1_str("SW1=");
            ser1_dec8u(sw1_ct);
            ser1_crlf(1);
        }

        //SW2
        if (sw2==TRUE){
            sw2=FALSE;
            sw2_ct++;
            ser1_str("SW2=");
            ser1_dec8u(sw2_ct);
            ser1_crlf(1);
        }
    }
    return modo;
}

//11 - LEDs
// Testar Leds
// VM, vn, Vm, VD, vd, Vd
char modo_11  (char modo) {
    char qtd,argc[4],argv[10];
    modo_ser1(modo);
    ser1_str(" Testar LEDs\n");
    led_vm();
    led_vd();
    while(TRUE){
        qtd=seri_cmdo(argc,argv,10);
        if(qtd>0){
            if (argv[0]=='X' || argv[0]=='x'){
                led_vm();
                led_vd();
                return modo;
            }
            if      (str_cmp(&argv[0], "VM")) led_VM();
            else if (str_cmp(&argv[0], "vm")) led_vm();
            else if (str_cmp(&argv[0], "Vm")) led_Vm();
            else if (str_cmp(&argv[0], "VD")) led_VD();
            else if (str_cmp(&argv[0], "vd")) led_vd();
            else if (str_cmp(&argv[0], "Vd")) led_Vd();
            else                             ser1_char('?');
        }
    }
    return modo;
}


char modo_0   (char modo) { modo_ser1(modo); return modo;}
char modo_1   (char modo) { modo_ser1(modo); return modo;}
char modo_2   (char modo) { modo_ser1(modo); return modo;}
char modo_3   (char modo) { modo_ser1(modo); return modo;}
char modo_4   (char modo) { modo_ser1(modo); return modo;}
char modo_5   (char modo) { modo_ser1(modo); return modo;}
char modo_6   (char modo) { modo_ser1(modo); return modo;}
char modo_7   (char modo) { modo_ser1(modo); return modo;}
char modo_8   (char modo) { modo_ser1(modo); return modo;}
char modo_9   (char modo) { modo_ser1(modo); return modo;}
char modo_12  (char modo) { modo_ser1(modo); return modo;}
char modo_13  (char modo) { modo_ser1(modo); return modo;}
char modo_14  (char modo) { modo_ser1(modo); return modo;}
char modo_15  (char modo) { modo_ser1(modo); return modo;}
char modo_16  (char modo) { modo_ser1(modo); return modo;}
char modo_17  (char modo) { modo_ser1(modo); return modo;}
char modo_18  (char modo) { modo_ser1(modo); return modo;}
char modo_19  (char modo) { modo_ser1(modo); return modo;}
char modo_20  (char modo) { modo_ser1(modo); return modo;}
char modo_99  (char modo) { ser1_str("Invalido");  return modo;}

// Imprimir modo no Serial
void modo_ser1(char modo){
    ser1_str("\r\nModo ");   ser1_dec8unz(modo);
}

