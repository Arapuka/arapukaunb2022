// Puka - Timer.h

#ifndef TIMER_H_
#define TIMER_H_




void clk_20mhz(void);


#endif /* TIMER_H_ */
