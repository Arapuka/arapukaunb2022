// Puka - Modos.c

#include <msp430.h>
#include "Modos.h"
#include "Serial.h"


char modo_0   (char modo) { modo_ser1(modo); return modo;}
char modo_1   (char modo) { modo_ser1(modo); return modo;}
char modo_2   (char modo) { modo_ser1(modo); return modo;}
char modo_3   (char modo) { modo_ser1(modo); return modo;}
char modo_4   (char modo) { modo_ser1(modo); return modo;}
char modo_5   (char modo) { modo_ser1(modo); return modo;}
char modo_6   (char modo) { modo_ser1(modo); return modo;}
char modo_7   (char modo) { modo_ser1(modo); return modo;}
char modo_8   (char modo) { modo_ser1(modo); return modo;}
char modo_9   (char modo) { modo_ser1(modo); return modo;}
char modo_10  (char modo) { modo_ser1(modo); return modo;}
char modo_11  (char modo) { modo_ser1(modo); return modo;}
char modo_12  (char modo) { modo_ser1(modo); return modo;}
char modo_13  (char modo) { modo_ser1(modo); return modo;}
char modo_14  (char modo) { modo_ser1(modo); return modo;}
char modo_15  (char modo) { modo_ser1(modo); return modo;}
char modo_16  (char modo) { modo_ser1(modo); return modo;}
char modo_17  (char modo) { modo_ser1(modo); return modo;}
char modo_18  (char modo) { modo_ser1(modo); return modo;}
char modo_19  (char modo) { modo_ser1(modo); return modo;}
char modo_20  (char modo) { modo_ser1(modo); return modo;}
char modo_99  (char modo) { ser1_str("Invalido");  return modo;}

// Imprimir modo no Serial
void modo_ser1(char modo){
    ser1_str("\r\nModo ");   ser1_dec8u(modo);
}

