// Puka - Globais.h

volatile char modo;      //Modo de opera��o
char *modos_lista[21]={
  "00) Nada\n",             //00
  "01) Livre_01\n",         //01
  "02) Livre_02\n",         //02
  "03) Livre_03\n",         //03
  "04) Livre_04\n",         //04
  "05) Livre_05\n",         //05
  "06) Livre_06\n",         //06
  "07) Livre_07\n",         //07
  "08) Livre_08\n",         //08
  "09) Livre_09\n",         //09
  "10) Livre_10\n",         //10
  "11) Livre_11\n",         //11
  "12) Livre_12\n",         //12
  "13) Livre_13\n",         //13
  "14) Livre_14\n",         //14
  "15) Livre_15\n",         //15
  "16) Livre_16\n",         //16
  "17) Livre_17\n",         //17
  "18) Livre_18\n",         //18
  "19) Livre_19\n",         //19
  "20) Livre_20\n"};        //20

////////////////////////////////////////////////////////////
/////////////////////// FILAS //////////////////////////////
////////////////////////////////////////////////////////////

// SERI e SERO: USCI_A1(PC) integradas
volatile char seri_fila[SERI_FILA_TAM]; //Espa�o para a fila serial de entrada
volatile int seri_pin, seri_pout;       //Ponteiros para usar a fila




