// Puka - Gpio.c

#include <msp430.h>
#include "Gpio.h"


void led_VM(void){  P1OUT |=  BIT0;  }   //VM=aceso
void led_vm(void){  P1OUT &= ~BIT0;  }   //VM=apagado
void led_Vm(void){  P1OUT ^=  BIT0;  }   //VM=invertido
void led_VD(void){  P4OUT |=  BIT7;  }   //VD=aceso
void led_vd(void){  P4OUT &= ~BIT7;  }   //VD=apagado
void led_Vd(void){  P4OUT ^=  BIT7;  }   //VD=invertido
void SCP1(void)  {  P2OUT |=  BIT5;  }   //Scope1=Alto
void scp1(void)  {  P2OUT &= ~BIT5;  }   //Scope1=Baixo
void Scp1(void)  {  P2OUT ^=  BIT5;  }   //Scope1=Invertido
void SCP2(void)  {  P2OUT |=  BIT4;  }   //Scope2=Alto
void scp2(void)  {  P2OUT &= ~BIT4;  }   //Scope2=Baixo
void Scp2(void)  {  P2OUT ^=  BIT4;  }   //Scope2=Invertido



void gpio_config(void){
    P2DIR &= ~BIT1;     //SW1
    P2REN |=  BIT1;     //SW1
    P2OUT |=  BIT1;     //SW1

    P1DIR &= ~BIT1;     //SW2
    P1REN |=  BIT1;     //SW2
    P1OUT |=  BIT1;     //SW2

    P1DIR |=  BIT0;     //Led1 = Vermelho
    P1OUT &= ~BIT0;     //Led1
    P4DIR |=  BIT7;     //Led2 = Verde
    P4OUT &= ~BIT7;     //Led2

    P2DIR |= BIT5 | BIT4;      //Scope, P2.5=Scope1 e P2.4=Scope2
    P2OUT &= ~(BIT5 | BIT4);   //Scope, P2.5=Scope1 e P2.4=Scope2
}



