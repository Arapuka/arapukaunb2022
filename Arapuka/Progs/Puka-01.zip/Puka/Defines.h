// Puka - Defines.h

#ifndef DEFINES_H_
#define DEFINES_H_

#define TRUE    1   //Verdadeiro
#define FALSE   0   //Falso
#define CR      0xD //Carriage Return
#define LF      0xA //Line Feed

#define SMCLK   20000000L   //SMCLK = 20 MHz
#define ACLK    32768       //ACLK = 32768 Hz

// Filas
// USCI_A0=Bluetooth e USCI_A1=PC
#define SERI_FILA_TAM 64   //Tamanho da fila circular de entrada serial


#endif /* DEFINES_H_ */
