// Puka - Gpio.h

#ifndef GPIO_H_
#define GPIO_H_

void led_VM(void);
void led_vm(void);
void led_Vm(void);
void led_VD(void);
void led_vd(void);
void led_Vd(void);
void SCP1(void);
void scp1(void);
void Scp1(void);
void SCP2(void);
void scp2(void);
void Scp2(void);
void gpio_config(void);


#endif /* GPIO_H_ */
