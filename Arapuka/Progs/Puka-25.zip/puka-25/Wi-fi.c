#include <msp430.h>
#include "Defines.h"
#include "Serial.h"
#include "Strings.h"
#include "Wi-fi.h"

void delay_ms(unsigned int ms)
{
  unsigned int i;
  for (i = 0; i <= ms; i++)
  {
    __delay_cycles(1000); //delay 1 ms
  }
}

void delay_s(float s)
{
  delay_ms((int)(s * 1000)); //delay 1 seg
}

void write_string(char *str)
{
  unsigned int i = 0;
  while (str[i] != '\0')
  {
    //write string byte by byte
    ser0_char(str[i++]);
  }
}
void tx_end(float delay) //fim do comando
{
  write_string("\r\n");
  delay_s(delay);
}

void tx(char *str, float delay) //enviar comando completo com \r\n
{
  write_string(str);
  tx_end(delay);
}

void tx_parcial(char *str) //enviar comandos sem \r\n
{
   write_string(str);
}

void esp_flash_config()
{
  //  Configurar m�dulo como AP e Cliente
  tx("AT+CWMODE_DEF=3", 2);

  tx_parcial("AT+CWJAP_DEF=");
  tx_parcial(WIFI_NETWORK_SSID);
  tx_parcial(",");
  tx_parcial(WIFI_NETWORK_PASS);
  tx_end(20);
}

void esp_init_config(void)
{
  //tx("ATE0", 1);        // Disable echo
  tx("AT+CIPMUX=0", 1); // Modo de conex�o �nica
}

void tcp_connect(void)
{
  tx_parcial("AT+CIPSTART=TCP,"); // Conex�o TCP
  tx_parcial(TCP_SERVER);
  tx_parcial(",");
  tx_parcial(TCP_PORT);
  tx_end(10);
}

void send_atcommand(char *data)
{
  tx("AT+CIPSEND=1", 1); // enviar byte
  tx(data, 0);
}

//C�digo abaixo extra�do de um c�digo no github para aux�lio
/*void main(void)
{
  init_uart();

  // Global Interrupt Enable
  __enable_interrupt();

  //IE2 &= ~UCA0RXIE; // Disable UART RX interrupt before we send data

  wait_ms(500);

  // need to run only once
  //esp_flash_config();

  esp_init_config();
  tcp_connect();

  send_atcommand("AT");

  returno 0;
}*/
