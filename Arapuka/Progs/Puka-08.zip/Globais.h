// Puka - Globais.h

// Lista impressa quando se entra com "?"
volatile char modo;      //Modo de opera��o
char *modos_lista[21]={
  "00) Nada\n",             //00
  "01) Livre_01\n",         //01
  "02) Livre_02\n",         //02
  "03) Livre_03\n",         //03
  "04) Livre_04\n",         //04
  "05) Livre_05\n",         //05
  "06) Livre_06\n",         //06
  "07) Livre_07\n",         //07
  "08) Livre_08\n",         //08
  "09) Livre_09\n",         //09
  "10) Testar SW\n",         //10 - SW
  "11) Testar LEDs\n",       //11 - LEDs
  "12) Livre_12\n",         //12
  "13) Livre_13\n",         //13
  "14) Livre_14\n",         //14
  "15) Livre_15\n",         //15
  "16) Livre_16\n",         //16
  "17) Livre_17\n",         //17
  "18) Livre_18\n",         //18
  "19) Livre_19\n",         //19
  "20) Livre_20\n"};        //20


////////////////////////////////////////////////////////////
///////////////////////  LCD  //////////////////////////////
////////////////////////////////////////////////////////////
volatile char i2c_tranca;   //TRUE indica que I2C est� sendo usado
volatile char lcd_tem;      //TRUE se LCD estiver presente
volatile char lcd_adr;      //Endere�o do PCF8574
volatile char lcd_flag;     //Indica que precisa atualizar LCD
volatile char lcd_buf[LCD_BUF_TAM]; //Buffer para todo LCD



////////////////////////////////////////////////////////////
/////////////////////// FILAS //////////////////////////////
////////////////////////////////////////////////////////////

// SERI e SERO: USCI_A1(PC) integradas
volatile char seri_fila[SERI_FILA_TAM]; //Espa�o para a fila serial de entrada
volatile int seri_pin, seri_pout;       //Ponteiros para usar a fila

// Timers - Vari�veis
volatile unsigned int  crono_cont;   //Contador para o Cron�metro (TA1)
volatile unsigned char flag_c_seg;   //Flag Cent�simos de segundo
volatile unsigned char flag_d_seg;   //Flag D�cimos de segundo
volatile unsigned char flag_seg;     //Flag Segundo
volatile unsigned char cont_c_seg;   //Contar cent�simos de segundo;
volatile unsigned char cont_d_seg;   //Contar d�cimos de segundo;
volatile unsigned char cont_seg;     //Contar segundos;
volatile unsigned char cont_min;     //Contar minutos;

// Vari�veis para monitorar as chaves
volatile char sw1_cont;     //0, 1, ..., SW_CONT_MAX
volatile char sw1_estado;   //Instant�neo: ABERTA, TRANSITO, FECHADA
volatile char sw1;          //TRUE se chave acionada
volatile char sw2_cont;     //0, 1, ..., SW_CONT_MAX
volatile char sw2_estado;   //Instant�neo: ABERTA, TRANSITO, FECHADA
volatile char sw2;          //TRUE se chave acionada



