#ifndef WI_FI_H_
#define WI_FI_H_

#define WIFI_NETWORK_SSID "ARAPUCAMOVEL"
#define WIFI_NETWORK_PASS "123arapuca"

#define TCP_SERVER "tcp.alejandroesquivel.com"
#define TCP_PORT "25"


#endif /* WI_FI_H_ */
