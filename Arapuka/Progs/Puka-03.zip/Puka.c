// Puka 09/02/2022
//
#include <msp430.h>
#include "Defines.h"
#include "Globais.h"
#include "Timer.h"
#include "Gpio.h"
#include "Lcd.h"
#include "Serial.h"
#include "Strings.h"
#include "Modos.h"

char sel_modo(void);

int main(void){
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
    clk_20mhz();
    crono_inic();           //Inicializar cron�metro
    crono_zera();           //Zerar cron�metro
    ta2_config();
    __enable_interrupt();
    gpio_config();
    ser1_config(BR_115200);
    seri_config();          //Configurar fila de entrada
    delay_10ms(10);         //Esperar USCI_A1 estabilizar
    //i2c_recupera();
    led_VM();
    while(sw1_estado==ABERTA)    ;
    led_vm();

    i2c_config(SCL_200k);   //Usar depois do ser1_config()





    lcd_tem=TRUE;

    //lcd_adr=0x3f;
    lcd_adr=0x27;


    while(TRUE){
        lcd_write(0x0);
        delay_seg(1);
        lcd_write(0xFF);
        delay_seg(1);
    }


    //Checar LCD e imprimir endere�o
    if (lcd_presente()==TRUE){  //Verificar o LCD
        ser1_str("\nLCD=");
        ser1_hex8(lcd_adr);
        lcd_inic();
    }
    else    ser1_str("\nSem LCD!");

    lcd_inic();
    delay_10ms(1);
    lcd_char('A');
    while(TRUE);

    lcd_dma_config();

    lcd_str("SW1?");
    led_VM();
    while(sw1_estado==ABERTA)    ;
    led_vm();
    lcdb_str(1,1,"Puka");
    lcd_atualiza();
    delay_10ms(10);
    lcdb_str(2,1,"Passou");
    lcd_atualiza();
    delay_10ms(10);
    lcdb_char(1,8,'8');
    lcdb_char(2,8,'9');
    lcd_atualiza();
    led_VD();

    while(TRUE);

    // La�o principal
    while(TRUE){
        ser1_str("\r\n==> Puka: ");
        modo=sel_modo();
        ser1_char('[');
        ser1_dec8u(modo);
        ser1_char(']');
        //modo=1;     //for�ar um dos modos
        switch(modo){
            case MODO_0:   modo_0(modo);  break;
            case MODO_1:   modo_1(modo);  break;
            case MODO_2:   modo_2(modo);  break;
            case MODO_3:   modo_3(modo);  break;
            case MODO_4:   modo_4(modo);  break;
            case MODO_5:   modo_5(modo);  break;
            case MODO_6:   modo_6(modo);  break;
            case MODO_7:   modo_7(modo);  break;
            case MODO_8:   modo_8(modo);  break;
            case MODO_9:   modo_9(modo);  break;
            case MODO_10:  modo_sw(modo); break;    //Testar as chaves
            case MODO_11:  modo_leds(modo);  break;
            case MODO_12:  modo_12(modo);  break;
            case MODO_13:  modo_13(modo);  break;
            case MODO_14:  modo_14(modo);  break;
            case MODO_15:  modo_15(modo);  break;
            case MODO_16:  modo_16(modo);  break;
            case MODO_17:  modo_17(modo);  break;
            case MODO_18:  modo_18(modo);  break;
            case MODO_19:  modo_19(modo);  break;
            case MODO_20:  modo_20(modo);  break;
            case MODO_99:  modo_99(modo);  break;   //Comando errado
        }
    }
    return 0;
}

// Selecionar o modo
char sel_modo(void){
    char x;
    char argc[4],argv[10];
    while(TRUE){
        //ser1_str("\n==> Modo?");
        //seri_come_crlf();
        while (seri_cmdo(argc, argv, 5)==0);
        if (argv[0]=='?'){
            ser1_crlf(1);
            for (x=0; x<MODO_TOT; x++){
                //while (sero_uso()>60);
                ser1_str(modos_lista[x]);
            }
        }
        else{
            x=str_2_num(argv);
            if (x>=0 && x<MODO_TOT)  break;
            else  x=99;              break;
        }
    }
    return x;
}

