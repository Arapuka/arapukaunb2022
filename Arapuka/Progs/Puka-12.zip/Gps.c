// Puka - Gps.c


// GPS simula porta serial por software
// S� recep��o est� implementada.
// P1.2 = GPS-TX
// Usa TA1 para sincronizar baud rate

#include <msp430.h>
#include "Defines.h"
#include "Gps.h"
#include "Gpio.h"
#include "Serial.h"




////////////////////////////////////////////////////
////////////////// Fila GPS ///////////////////////
///////////// MSP430 <== GPS ///////////////////////
/////// Interrup��o chama gps_poe() ///////////////
/////// Ler a fila como gps_tira()  ///////////////
////////////////////////////////////////////////////


// Informa qual o pr�ximo byte da fila SERI
// N�o altera estado dos ponteiros
// Chamada fora das interrup��es
// FALSE = fila vazia
char gps_xereta(char *cha){
  int pin,pout;
  __disable_interrupt();
  pout=gps_pout; //Copiar
  pin=gps_pin;   //ponteiros
  __enable_interrupt();
  pout++;
  if (pout == GPS_FILA_TAM)    pout=0;
  if (pout == pin){
    return FALSE;
  }
  else{
    *cha=gps_fila[pout];
    return TRUE;
  }
}

// Colocar um byte na fila SERI
// Chamada dentro Interrup��es de RX USCI_A1
char gps_poe(char cha){
  if (gps_pin == gps_pout){
    gps_cheia();     //Msg de fila cheia
    return FALSE;     //SERI cheia
  }
  else{
    gps_fila[gps_pin++]=cha;
    if (gps_pin==GPS_FILA_TAM)
      gps_pin=0;
    return TRUE;
  }
}

// Mensagem de Fila SERI Cheia
void gps_cheia(void){
  __disable_interrupt();
  ser1_str("\nERRO: GPS Cheia!\n");
  gps_dump();
  ser1_str("\nTravado!");
  while(TRUE);
}

// Tirar um byte da fila SERI
// Fun��o chamada fora das interrup��es
char gps_tira(char *cha){
  int pout_aux;
  __disable_interrupt();
  pout_aux=gps_pout+1;
  if (pout_aux == GPS_FILA_TAM)    pout_aux=0;
  if (pout_aux == gps_pin){
    __enable_interrupt();
    return FALSE;
  }
  else{
    *cha=gps_fila[pout_aux];
    gps_pout=pout_aux;
    __enable_interrupt();
    return TRUE;
  }
}

// Imprimir fila de entrada SERI
// Para debug, chamada quando fila enche
void gps_dump(void){
    int i;
    ser1_str("\nGPS:  Tamanho=");   ser1_dec8u(GPS_FILA_TAM);
    ser1_str("  gps_pin=");         ser1_dec8u(gps_pin);
    ser1_str("  gps_pout=");        ser1_dec8u(gps_pout);
    ser1_crlf(1);
    for (i=0; i<GPS_FILA_TAM; i+=16){
        ser1_dec8u(i);
        ser1_char(':');
        ser1_char(' ');
        ser1_linha(&gps_fila[i]);
    }
}

// ISR TA0CCR0
#pragma vector = 53
__interrupt void isr_ta0ccr0(void){
    if (gps_estado==18){    //Terminou?
        TA0CCTL0 &= ~CCIE;  //Desab Interrup TA1
        P1IFG &= ~BIT2;     //Apagar pedidos anteriores
        P1IE  |=  BIT2;     //Hab Interup P1.2
        gps_poe(gps_dado);
    }
    else{
        if ((gps_estado&BIT0)==0){   //� par
            gps_dado = gps_dado>>1;
            if ((P1IN&BIT2) == BIT2) gps_dado |= BIT7;
            //gps_dado++;
        }
    }
    gps_estado++;
}

// ISR P1.2
// Detecta o START da serial enviada pelo GPS
#pragma vector = 47
__interrupt void isr_p1(void){
    P1IV;       //Apagar o pedido
    TA0CTL |= TACLR;
    TA0CCTL0 &= ~CCIFG; //Apagar poss�vel pedido anterior
    TA0CCTL0 |= CCIE;
    P1IFG &= ~BIT2;
    P1IE  &=  ~BIT2;    //Desab Interup P1.2
    gps_estado=0;       //Iniciar recep��o
}

// Inicializar fila SERI
// Prepara a porta de GPIO (P1.2)
// Prepara Timer TA0 para operar 9.600
// 20E6/19.200 = 1.041
void gps_config(void){
  gps_pin=1;
  gps_pout=0;
  P1DIR &= ~BIT2;
  P1REN |=  BIT2;
  P1OUT |=  BIT2;   //Pullup
  P1IES |=  BIT2;   //Interup flanco descida
  P1IFG |= ~BIT2;   //Apagar poss�vel Interup anterior
  P1IE  |=  BIT2;   //Hab Interup
  TA0CTL = TASSEL_2 | MC_1;
  TA0CCR0 = 1041;   // 20E6/19.200 = 1.041
}


