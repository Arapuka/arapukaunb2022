// Puka - Gps.h

#ifndef GPS_H_
#define GPS_H_

extern volatile char gps_fila[GPS_FILA_TAM]; //Espa�o para a fila serial de entrada
extern volatile int gps_pin, gps_pout;       //Ponteiros para usar a fila
extern volatile int gps_estado;              //Estado do receptor por software
extern volatile char gps_dado;               //Montar o dado que chega serialmente do GPS


char gps_xereta(char *cha);
void gps_config(void);
char gps_poe(char cha);
void gps_cheia(void);
char gps_tira(char *cha);
void gps_dump(void);







#endif /* GPS_H_ */
